ZSARRA sample pictures
====================
1-named-by-sku/            Pictures named after the product SKU. Select them in Bulk import > Step 2
                           WITHOUT an image report. ZM-201.jpg is the cover; a second picture would be ZM-201_2.jpg.
2-use-with-image-report/   Pictures with their own names. Select them in Step 2 TOGETHER WITH
                           zsarra-image-report-sample.xlsx (or .csv) so each file is matched to its product.
Import zara-products-sample.xlsx (or .csv) first so the products exist.
